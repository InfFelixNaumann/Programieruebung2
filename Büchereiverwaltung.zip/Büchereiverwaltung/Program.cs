﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Json.Net;
using Newtonsoft.Json.Linq;
using System.ComponentModel;
using static Büchereiverwaltung.Exemplarkatalog;

namespace Büchereiverwaltung
{
    /*Interface
    public interface IProduct
    {
        public List<Item> JSON();
        void Anzeige();
        public List<Item> Neu(List<Item> inventar);
        void Löschen();
        void Bearbeiten();
    }*/

    class Program
    {
        static void Main(string[] args)
        {
            var inventar = JSONDateienEinlesen.JSONeinlesen();
            var magazininventar = JSONDateienEinlesen.MagazinEinlesen();
            var auswahl = EingabeHolen();
            var exemplare = Exemplarkatalog.ExemplarlisteErstellen(inventar, magazininventar);
            AktionBestimmen(auswahl, inventar, magazininventar, exemplare);
        }
        

        public static int TypAuswählen()
        {
            Console.WriteLine("Welche Art von Product wollen Sie hinzufügen?");
            Console.WriteLine("1- Buch");
            Console.WriteLine("2- Magazin");
            return Convert.ToInt32(Console.ReadLine());
        }
        private static string EingabeHolen()
        {
            Console.WriteLine();
            Console.WriteLine("Was möchten sie tun?");
            Console.WriteLine("1- gesamtes Inventar anzeigen");
            Console.WriteLine("2- neues Buch oder Magazin hinzufügen");
            Console.WriteLine("3- Buch aus Inventar entfernen");
            Console.WriteLine("4- Daten zu einem Buch ansehen und bearbeiten");
            Console.WriteLine("5- alle noch nicht abgeschlossen Verleihvorgänge anzeigen");
            Console.WriteLine("6- ein Buch verleihen");
            Console.WriteLine("7- ein Proukt zurücknehmen");
            Console.WriteLine("8- Verleihdaten bearbeiten  (noch nicht funktionsfähig)");
            Console.WriteLine("x - Beenden");
            return Console.ReadLine().ToLower();
        }
        private static void AktionBestimmen(string auswahl, List<Buch> inventar, List<Magazin> magazininventar, List<Exemplar> exemplar)
        {
            //IProduct buchinterface = new Buchinterface();
            var verleih = JSONDateienEinlesen.JSONVerleih();
            var magazine = JSONDateienEinlesen.MagazinEinlesen();
            int typ;
            while (auswahl != "x")
            {
                switch (auswahl)
                {
                    case "1":
                        //buchinterface.Anzeige();
                        /*BuchKatalog.AlleBücher(inventar);
                        MagazinKatalog.AlleMagazine(magazine);
                        eBookKatalog.AlleeBooks(inventar);
                        ePaperKatalog.AlleEPaper(magazine);*/
                        GanzesInventarAnzeigen(inventar, magazine, exemplar);
                        break;
                    case "2":
                        typ = TypAuswählen();
                        //buchinterface.Neu(inventar);
                        switch (typ)
                        {
                            case 1: inventar = BuchKatalog.NeuesBuch(inventar); break;
                            case 2: magazininventar = MagazinKatalog.NeuesMagazin(magazininventar); break;
                        }
                        break;
                    case "3":
                        //buchinterface.Löschen();
                        typ = TypAuswählen();
                        switch (typ)
                        {
                            case 1: inventar = BuchKatalog.BuchEntfernen(inventar); break;
                            case 2: magazininventar = MagazinKatalog.MagazinEntfernen(magazininventar); break;
                        }
                        break;
                    case "4":
                        //buchinterface.Bearbeiten();
                        typ = TypAuswählen();
                        switch (typ)
                        {
                            case 1:
                                var BuchID = BuchKatalog.BuchInfo(inventar);
                                inventar = BuchKatalog.BuchBearbeiten(inventar, BuchID);
                                break;
                            case 2:
                                var MagazinID = MagazinKatalog.MagazinInfo(magazininventar);
                                magazininventar = MagazinKatalog.MagazinBearbeiten(magazininventar, MagazinID);
                                break;
                        }
                        break;
                    case "5":
                        Verleih.AlleLeihvorgänge(inventar,magazine, verleih, exemplar);
                        break;
                    case "6":
                        exemplar= Verleih.neuerVerleih(exemplar);
                        break;
                    case "7":
                        verleih = Verleih.Rückgabe(verleih);
                        break;
                    case "8":
                        Verleih.VerleihInfo(inventar);
                        break;
                    case "x":
                        Environment.Exit(0);
                        break;
                    default: break;
                }
                auswahl = EingabeHolen();
            }
        }
    }
}
