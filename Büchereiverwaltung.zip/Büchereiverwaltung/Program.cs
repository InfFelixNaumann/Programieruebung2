﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Json.Net;
using Newtonsoft.Json.Linq;
using System.ComponentModel;

namespace Büchereiverwaltung
{
    //Interface
    public interface IProduct
    {
        public List<Item> JSON();
        void Anzeige();
        public List<Item> Neu(List<Item> inventar);
        void Löschen();
        void Bearbeiten();
    }

    class Program
    {
        static void Main(string[] args)
        {
            var inventar = JSONeinlesen();
            Exemplar.ExemplarlisteErstellen();
            Buch.Main(inventar);
        }
        public static List<Item> JSONeinlesen()
        {
            using (StreamReader r = new StreamReader("books.json"))
            {
                string json = r.ReadToEnd();
                List<Item> items = JsonConvert.DeserializeObject<List<Item>>(json);
                return items;
            }
        }

        public class Exemplarliste
        {
            public string BuchID;
            public string Anmerkung;
        }
    }
}
