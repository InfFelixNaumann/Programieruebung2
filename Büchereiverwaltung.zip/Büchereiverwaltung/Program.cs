﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Json.Net;
using Newtonsoft.Json.Linq;
using System.ComponentModel;

namespace Büchereiverwaltung
{
    //Interface
    public interface IProduct
    {
        void JSON();
        void Anzeige();
        void Neu();
        void Löschen();
        void Bearbeiten();
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            //Exemplar.ExemplarlisteErstellen();
            var inventar = JSONeinlesen();
            Exemplar.ExemplarlisteErstellen();
            Buch.Main(inventar);
        }
        public static List<Item> JSONeinlesen()
        {
            using (StreamReader r = new StreamReader("books.json"))
            {
                string json = r.ReadToEnd();
                List<Item> items = JsonConvert.DeserializeObject<List<Item>>(json);
                return items;
            }
        }
        public class Item
        {
            public string author;
            public string country;
            public string imageLink;
            public string language;
            public string link;
            public int pages;
            public string title;
            public int year;
        }
        public class Exemplarliste
        {
            public string BuchID;
            public string Anmerkung;
        }
    }
}
