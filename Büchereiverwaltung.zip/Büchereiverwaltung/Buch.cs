﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using static Büchereiverwaltung.Program;

namespace Büchereiverwaltung
{
    public class Item
    {
        public string author;
        public string country;
        public string imageLink;
        public string language;
        public string link;
        public int pages;
        public string title;
        public int year;
    }

    class Buch
    {
        public static void Main(List<Item> inventar)
        {
            var auswahl = EingabeHolen();
            AktionBestimmen(auswahl, inventar);
        }

        private static string EingabeHolen()
        {
            Console.WriteLine();
            Console.WriteLine("Was möchten sie tun?");
            Console.WriteLine("1- alle Bücher und Magazine anzeigen");
            Console.WriteLine("2- neues Buch hinzufügen");
            Console.WriteLine("3- Buch aus Inventar entfernen");
            Console.WriteLine("4- Daten zu einem Buch ansehen und bearbeiten");
            Console.WriteLine("5- alle noch nicht abgeschlossen Verleihvorgänge anzeigen");
            Console.WriteLine("6- ein Buch verleihen");
            Console.WriteLine("7- ein Buch zurücknehmen");
            Console.WriteLine("8- Verleihdaten bearbeiten");
            Console.WriteLine("x - Beenden");
            return Console.ReadLine().ToLower();
        }
        private static void AktionBestimmen(string auswahl, List<Item> inventar)
        {
            //IProduct buchinterface = new Buchinterface();
            var verleih = Verleih.JsonAuslesen();
            var magazine = Magazin.MagazinEinlesen();
            while (auswahl != "x")
            {
                switch (auswahl)
                {
                    case "1":
                        //buchinterface.Anzeige();
                        AlleBücher(inventar);
                        Magazin.AlleMagazine(magazine);
                        break;
                    case "2":
                        //buchinterface.Neu(inventar);
                        inventar= NeuesBuch(inventar);
                        break;
                    case "3":
                        //buchinterface.Löschen();
                        inventar = BuchEntfernen(inventar);
                        break;
                    case "4":
                        //buchinterface.Bearbeiten();
                        var BuchID= BuchInfo(inventar);
                        //inventar = BuchBearbeiten(inventar, BuchID);
                        break;
                    case "5":
                        Verleih.AlleLeihvorgänge(inventar, verleih);
                        break;
                    case "6":
                        Verleih.neuerVerleih();
                        break;
                    case "7":
                        verleih = Verleih.Rückgabe(verleih);
                        break;
                    case "8":
                        break;
                    case "x":
                        Environment.Exit(0);
                        break;
                    default: break;
                }
                auswahl = EingabeHolen();
            }
        }
        public static void AlleBücher(List<Item> inventar)
        {
            Console.WriteLine("Bücher:");
            Console.WriteLine("__________");
            //List<Item> inventar = Program.JSONeinlesen();
            foreach (Item i in inventar)
            {
                Console.WriteLine("[{0}] {1}: '{2}' , {3}. Quelle: {4}", inventar.IndexOf(i), i.author, i.title, i.year, i.link);
            }
        }
        public static List<Item> NeuesBuch(List<Item> inventar)
        {

            Console.WriteLine("Geben sie bitte die Daten zum Buch ein");
            var initialJson = File.ReadAllText("books.json");
            //var array = JArray.Parse(initialJson);
            Console.WriteLine("Autor:");
            var autor = Console.ReadLine();
            Console.WriteLine("Land:");
            var country = Console.ReadLine();
            Console.WriteLine("Bildlink:");
            var imagelink = Console.ReadLine();
            Console.WriteLine("Sprache:");
            var language = Console.ReadLine();
            Console.WriteLine("Link:");
            var link = Console.ReadLine();
            Console.WriteLine("Seitenzahl:");
            var pages = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Titel:");
            var title = Console.ReadLine();
            Console.WriteLine("Erscheinungsjahr");
            var year = Convert.ToInt32(Console.ReadLine());

            JArray feld = JArray.Parse(initialJson);
            var itemToAdd = new JObject();
            {
                itemToAdd["author"] = autor;
                itemToAdd["country"] = country;
                itemToAdd["imageLink"] = imagelink;
                itemToAdd["language"] = language;
                itemToAdd["link"] = link;
                itemToAdd["pages"] = pages;
                itemToAdd["title"] = title;
                itemToAdd["year"] = year;
            }
            feld.Add(itemToAdd);
            using (StreamWriter file = File.CreateText("books.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                //serialize object directly into file stream
                serializer.Serialize(file, feld);
            }
            return inventar;
        }
        public static List<Item> BuchEntfernen(List<Item> inventar)
        {
            Console.WriteLine("Geben Sie die ID des Buches ein welches entfernt werden soll");
            var id = Convert.ToInt32(Console.ReadLine());
            inventar.Remove(inventar[id]);
            return inventar;
        }
        public static int BuchInfo(List<Item> inventar)
        {
            Console.WriteLine("Geben Sie die Id des Buches an dessen Informationen Sie einsehen möchten");
            var BuchID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Autor: {0}   [1]", inventar[BuchID].author);
            Console.WriteLine("Titel: {0}   [2]", inventar[BuchID].title);
            Console.WriteLine("Land: {0}    [3]", inventar[BuchID].country);
            Console.WriteLine("Sprache: {0} [4]", inventar[BuchID].language);
            Console.WriteLine("Jahr: {0}    [5]", inventar[BuchID].year);
            Console.WriteLine("Seitenzahl: {0}  [6]", inventar[BuchID].pages);
            Console.WriteLine("Bildlink: {0}    [7]", inventar[BuchID].imageLink);
            Console.WriteLine("Link: {0}    [8]", inventar[BuchID].link);
            Console.WriteLine();
            return (BuchID);
        }
        public static List<Item> BuchBearbeiten(List<Item> inventar, int BuchID)
        {
            string input = "0";
            string neueeingabe;
            while (input != "x")
            {
                Console.WriteLine("Wählen Sie den zu bearbitenden Eintrag (x zum beenden)");
                input = Console.ReadLine().ToLower();
                if (input == "x")
                {
                    return inventar;
                }
                Console.WriteLine("Bitte geben Sie den neuen Wert ein");
                neueeingabe = Console.ReadLine();
                switch (input)
                {
                    case "1": inventar[BuchID].author = neueeingabe; break;
                    case "2": inventar[BuchID].title = neueeingabe; break;
                    case "3": inventar[BuchID].country = neueeingabe; break;
                    case "4": inventar[BuchID].language = neueeingabe; break;
                    case "5": inventar[BuchID].year = Convert.ToInt32(neueeingabe); break;
                    case "6": inventar[BuchID].pages = Convert.ToInt32(neueeingabe); break;
                    case "7": inventar[BuchID].imageLink = neueeingabe; break;
                    case "8": inventar[BuchID].link = neueeingabe; break;
                }
            }
            return inventar;
        }

    }
    /*public class Buchinterface : IProduct
    {
        //implementierung der Interfaces
        public List<Item> Inventar {
            get{ return JSONeinlesen(); }
            set { }
        }
        List<Item> IProduct.JSON()
        {
            var inventar = JSONeinlesen();
            return inventar;
        } 
        void IProduct.Anzeige()
        {
            Console.WriteLine("Hallo");
            var inventar = JSONeinlesen();
            Buch.AlleBücher(inventar);
        }
        List<Item> IProduct.Neu(List<Item> inventar)
        {
            inventar = Buch.NeuesBuch(inventar);
            return inventar;
        }
        void IProduct.Löschen()
        {
            var inventar = JSONeinlesen();
            inventar = Buch.BuchEntfernen(inventar);
        }
        void IProduct.Bearbeiten()
        {
            var inventar = JSONeinlesen();
            var BuchID = Buch.BuchInfo(inventar);
            inventar = Buch.BuchBearbeiten(inventar, BuchID);
        }

    }*/
}
