﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using static Büchereiverwaltung.Program;

namespace Büchereiverwaltung
{
    class Verleih
    {
        public static void AlleLeihvorgänge(List<Buch> inventar, List<Leihliste> verleih)
        {
            foreach (Leihliste i in verleih)
            {
                Console.WriteLine("Das Buch {0} wurde an {1} am {2} verliehen. Rückgabe fällig am: {3}", inventar[i.buch].title, i.kunde, i.verleihdatum.Date, i.rückgabedatum.Date);
            }
        }
        public static List<Leihliste> JsonAuslesen()
        {
            using (StreamReader r = new StreamReader("Leihliste.json"))
            {
                string json = r.ReadToEnd();
                List<Leihliste> leih = JsonConvert.DeserializeObject<List<Leihliste>>(json);
                return leih;
            }
        }
        public static void neuerVerleih()
        {
            Console.WriteLine("Kundenname:");
            var kunde = Console.ReadLine();
            Console.WriteLine("BuchID:");
            var buch = Convert.ToInt32(Console.ReadLine());


            var verleihdatum = DateTime.Now.Date;
            var rückgabedatum = verleihdatum.AddDays(30);
            var json = File.ReadAllText("Leihliste.json");
            if (json.Length > 0)
            {
                JArray feld = JArray.Parse(json);
                var itemToAdd = new JObject();
                {
                    itemToAdd["kunde"] = kunde;
                    itemToAdd["buch"] = buch;
                    itemToAdd["verleihdatum"] = verleihdatum;
                    itemToAdd["rückgabedatum"] = rückgabedatum;
                }
                feld.Add(itemToAdd);
                using StreamWriter file = File.CreateText("Leihliste.json");
                JsonSerializer serializer = new JsonSerializer();
                //serialize object directly into file stream
                serializer.Serialize(file, feld);
            }
            else
            {
                List<Leihliste> list = new List<Leihliste>();
                list.Add(new Leihliste()
                {
                    kunde = kunde,
                    buch = buch,
                    verleihdatum = verleihdatum,
                    rückgabedatum = rückgabedatum
                });
                using StreamWriter file = File.CreateText("Leihliste.json");
                JsonSerializer serializer = new JsonSerializer();
                //serialize object directly into file stream
                serializer.Serialize(file, list);
            }


        }
        public static List<Leihliste> Rückgabe(List<Leihliste> verleih)
        {
            Console.WriteLine("Welcher Verleihvorgang soll beendet werden?");
            var rück = Convert.ToInt32(Console.ReadLine());
            verleih.Remove(verleih[rück]);
            return verleih;
        }

        public static void VerleihInfo(List<Buch> inventar)
        { 
            //nur teilweise funktionsfähig
            //Verleihdauer muss noch berechnet werden
            var verleih = JsonAuslesen();
            Console.WriteLine("Geben sie die ID des Verleihvorgangs an welchen Sie bearbeiten wollen");
            var id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Buch: ", inventar[verleih[id].buch].title);
            Console.WriteLine("Kunde: ", verleih[id].kunde);
            Console.WriteLine("Rückgabedatum: ",verleih[id].rückgabedatum);
        }
    }
    public class Leihliste
    {
        public string kunde;
        public int buch;
        public DateTime verleihdatum;
        public DateTime rückgabedatum;
    }



}
