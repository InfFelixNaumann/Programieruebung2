﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using static Büchereiverwaltung.Program;
using static Büchereiverwaltung.Exemplarkatalog;

namespace Büchereiverwaltung
{
    class Verleih
    {
        public static void AlleLeihvorgänge(List<Buch> inventar, List<Leihliste> verleih)
        {
            foreach (Leihliste i in verleih)
            {
                Console.WriteLine("Das Buch {0} wurde an {1} am {2} verliehen. Rückgabe fällig am: {3}", inventar[i.buch].title, i.kunde, i.verleihdatum.Date, i.rückgabedatum.Date);
            }
        }

        public static List<Exemplar> neuerVerleih(List<Exemplar> exemplar)
        {
            Console.WriteLine("BuchID:");
            var buchid = Convert.ToInt32(Console.ReadLine());
            foreach (Exemplar i in exemplar)
            {
                if (i.BuchID == buchid)
                {
                    if (i.Anzahl <= 0)
                    {
                        Console.WriteLine("Es ist momentan kein Exemplar dieses Buches verfügbar");
                    }
                    else
                    {
                        i.Anzahl--;
                        Console.WriteLine("Kundenname:");
                        var kunde = Console.ReadLine();
                        var verleihdatum = DateTime.Now.Date;
                        var rückgabedatum = verleihdatum.AddDays(30);
                        var json = File.ReadAllText("Leihliste.json");

                        if (json.Length > 0)
                        {
                            JArray feld = JArray.Parse(json);
                            var itemToAdd = new JObject();
                            {
                                itemToAdd["kunde"] = kunde;
                                itemToAdd["buch"] = buchid;
                                itemToAdd["verleihdatum"] = verleihdatum;
                                itemToAdd["rückgabedatum"] = rückgabedatum;
                            }
                            feld.Add(itemToAdd);
                            using StreamWriter file = File.CreateText("Leihliste.json");
                            JsonSerializer serializer = new JsonSerializer();
                            //serialize object directly into file stream
                            serializer.Serialize(file, feld);
                        }
                        else
                        {
                            List<Leihliste> list = new List<Leihliste>();
                            list.Add(new Leihliste()
                            {
                                kunde = kunde,
                                buch = buchid,
                                verleihdatum = verleihdatum,
                                rückgabedatum = rückgabedatum
                            });
                            using StreamWriter file = File.CreateText("Leihliste.json");
                            JsonSerializer serializer = new JsonSerializer();
                            //serialize object directly into file stream
                            serializer.Serialize(file, list);
                        }
                    }

                }
            }
            return exemplar;
        }
        public static List<Leihliste> Rückgabe(List<Leihliste> verleih)
        {
            Console.WriteLine("Welcher Verleihvorgang soll beendet werden?");
            var rück = Convert.ToInt32(Console.ReadLine());
            verleih.Remove(verleih[rück]);
            return verleih;
        }

        public static void VerleihInfo(List<Buch> inventar)
        { 
            //nur teilweise funktionsfähig
            //Verleihdauer muss noch berechnet werden
            var verleih = JSONDateienEinlesen.JSONVerleih();
            Console.WriteLine("Geben sie die ID des Verleihvorgangs an welchen Sie bearbeiten wollen");
            var id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Buch: ", inventar[verleih[id].buch].title);
            Console.WriteLine("Kunde: ", verleih[id].kunde);
            Console.WriteLine("Rückgabedatum: ",verleih[id].rückgabedatum);
        }
    }
}
