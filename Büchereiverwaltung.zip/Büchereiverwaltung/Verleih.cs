﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using static Büchereiverwaltung.Program;
using static Büchereiverwaltung.Exemplarkatalog;

namespace Büchereiverwaltung
{
    class Verleih
    {

        public static void AlleLeihvorgänge(List<Buch> inventar, List<Magazin> magazin, List<Leihliste> verleih, List<Exemplar> exemplar)
        {
            if (verleih.Count > 0)
            {
                var titel = "";
                foreach (Leihliste i in verleih)
                {
                    switch (exemplar[i.buch].Typ)
                    {
                        case "Buch": titel = inventar[i.buch].title; break;
                        case "Magazin": titel = magazin[exemplar[i.buch].ID].Titel; break;
                        case "EBook": titel = inventar[exemplar[i.buch].ID].title; break;
                        case "EPaper": titel = magazin[exemplar[i.buch].ID].Titel; break;
                    }
                    Console.WriteLine("[{0}] Das Buch {1} wurde an {2} am {3} verliehen. Rückgabe fällig am: {4}", verleih.IndexOf(i), titel, i.kunde, i.verleihdatum.Date, i.rückgabedatum.Date);
                }
            }
            else Console.WriteLine("Es existieren zur Zeit keine aktiven Leihvorgänge");
        }

        public static List<Exemplar> neuerVerleih(List<Exemplar> exemplar)
        {
            Console.WriteLine("BuchID:");
            var buchid = Convert.ToInt32(Console.ReadLine());
            var verleihdatum = DateTime.Now.Date;
            var rückgabedatum = verleihdatum.AddDays(30);
            foreach (Exemplar i in exemplar)
            {
                if (exemplar.IndexOf(i) == buchid)
                {
                    switch (i.Typ)
                    {
                        case "Buch": case "EBook":
                            if (i.Anzahl <= 0 && i.Typ == "Buch")
                            {
                                Console.WriteLine("Es ist momentan kein Exemplar dieses Buches verfügbar");
                            }
                            else
                            {
                                Console.WriteLine("Kundenname:");
                                var kunde = Console.ReadLine();
                                var json = File.ReadAllText("Leihliste.json");

                                if (json.Length > 0)
                                {
                                    JArray feld = JArray.Parse(json);
                                    var itemToAdd = new JObject();
                                    {
                                        itemToAdd["kunde"] = kunde;
                                        itemToAdd["buch"] = buchid;
                                        itemToAdd["verleihdatum"] = verleihdatum;
                                        itemToAdd["rückgabedatum"] = rückgabedatum;
                                    }
                                    feld.Add(itemToAdd);
                                    using StreamWriter file = File.CreateText("Leihliste.json");
                                    JsonSerializer serializer = new JsonSerializer();
                                    serializer.Serialize(file, feld);
                                }
                                else
                                {
                                    List<Leihliste> list = new List<Leihliste>();
                                    list.Add(new Leihliste()
                                    {
                                        kunde = kunde,
                                        buch = buchid,
                                        verleihdatum = verleihdatum,
                                        rückgabedatum = rückgabedatum
                                    });
                                    using StreamWriter file = File.CreateText("Leihliste.json");
                                    JsonSerializer serializer = new JsonSerializer();
                                    serializer.Serialize(file, list);
                                }
                            }
                            break;
                        case "Magazin":
                        case "EPaper":
                            if (i.Anzahl <= 0)
                            {
                                Console.WriteLine("Es ist momentan kein Exemplar dieses Buches verfügbar");
                            }
                            else
                            {
                                Console.WriteLine("Kundenname:");
                                var kunde = Console.ReadLine();
                                rückgabedatum= verleihdatum.AddDays(2);
                                var json = File.ReadAllText("Leihliste.json");

                                if (json.Length > 0)
                                {
                                    JArray feld = JArray.Parse(json);
                                    var itemToAdd = new JObject();
                                    {
                                        itemToAdd["kunde"] = kunde;
                                        itemToAdd["buch"] = buchid;
                                        itemToAdd["verleihdatum"] = verleihdatum;
                                        itemToAdd["rückgabedatum"] = rückgabedatum;
                                    }
                                    feld.Add(itemToAdd);
                                    using StreamWriter file = File.CreateText("Leihliste.json");
                                    JsonSerializer serializer = new JsonSerializer();
                                    serializer.Serialize(file, feld);
                                }
                                else
                                {
                                    List<Leihliste> list = new List<Leihliste>();
                                    list.Add(new Leihliste()
                                    {
                                        kunde = kunde,
                                        buch = buchid,
                                        verleihdatum = verleihdatum,
                                        rückgabedatum = rückgabedatum
                                    });
                                    using StreamWriter file = File.CreateText("Leihliste.json");
                                    JsonSerializer serializer = new JsonSerializer();
                                    serializer.Serialize(file, list);
                                }
                            }
                            break;
                    }
                    if (i.Typ== "Buch" || i.Typ=="Magazin")
                    {
                        i.Anzahl--;
                    }
                }
            }
            return exemplar;
        }
        public static List<Leihliste> Rückgabe(List<Leihliste> verleih)
        {
            Console.WriteLine("Welcher Verleihvorgang soll beendet werden?");
            var rück = Convert.ToInt32(Console.ReadLine());
            verleih.Remove(verleih[rück]);
            return verleih;
        }

        public static void VerleihInfo(List<Buch> inventar)
        { 
            var verleih = JSONDateienEinlesen.JSONVerleih();
            Console.WriteLine("Geben sie die ID des Verleihvorgangs an welchen Sie bearbeiten wollen");
            var id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Buch: {0}    [0]", inventar[verleih[id].buch].title);
            Console.WriteLine("Kunde: {1}   [1]", verleih[id].kunde);
            Console.WriteLine("Rückgabedatum: {2}   [2]",verleih[id].rückgabedatum);
        }
    }
}
