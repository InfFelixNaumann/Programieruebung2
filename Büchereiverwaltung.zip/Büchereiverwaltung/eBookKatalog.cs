﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Büchereiverwaltung
{
    class eBookKatalog
    {
        /*public static void AlleeBooks(List<Buch> inventar)
        {
            Console.WriteLine("eBook:");
            Console.WriteLine("__________");
            //List<Item> inventar = Program.JSONeinlesen();
            foreach (Buch i in inventar)
            {
                Console.WriteLine("[{0}] {1}: '{2}' , {3}. Link: HierStehtDerDownloaLink", inventar.IndexOf(i), i.author, i.title, i.year);
            }
        }*/

    }
}
