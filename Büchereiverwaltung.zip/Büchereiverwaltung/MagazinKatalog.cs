﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.ComponentModel;
using System.Text.Json.Serialization;
using System.Dynamic;

namespace Büchereiverwaltung
{
    class MagazinKatalog
    {

        public static void AlleMagazine(List<Magazin> inventar)
        {
            Console.WriteLine("Magazine:");
            Console.WriteLine("__________");
            foreach (Magazin i in inventar)
            {
                Console.WriteLine("[{0}] {1}: '{2}'", inventar.IndexOf(i),i.Verlag, i.Titel);
                Console.WriteLine("Gruppe: {0}", i.Gruppe);
                Console.WriteLine("Sachgruppe: {0}", i.Sachgruppe);
                Console.WriteLine();
            }
        }
        public static List<Magazin> NeuesMagazin(List<Magazin> inventar)
        {
            Console.WriteLine("Geben sie bitte die Daten zum Magazin ein");
            var initialJson = File.ReadAllText("Magazine.json");
            Console.WriteLine("Titel:");
            var titel = Console.ReadLine();
            Console.WriteLine("Gruppe:");
            var gruppe = Console.ReadLine();
            Console.WriteLine("Sachgruppe:");
            var sachgruppe = Console.ReadLine();
            Console.WriteLine("Verlag:");
            var verlag = Console.ReadLine();

            JArray feld = JArray.Parse(initialJson);
            var itemToAdd = new JObject();
            {
                itemToAdd["titel"] = titel;
                itemToAdd["Gruppe"] = gruppe;
                itemToAdd["Sachgruppe"] = sachgruppe;
                itemToAdd["Verlag"] = verlag;
            }
            feld.Add(itemToAdd);
            using (StreamWriter file = File.CreateText("Magazine.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, feld);
            }
            return inventar;
        }
        public static List<Magazin> MagazinEntfernen(List<Magazin> inventar)
        {
            Console.WriteLine("Geben Sie die ID des Magazins ein welches entfernt werden soll");
            var id = Convert.ToInt32(Console.ReadLine());
            inventar.Remove(inventar[id]);
            return inventar;
        }
        public static int MagazinInfo(List<Magazin> inventar)
        {
            Console.WriteLine("Geben Sie die Id des Buches an dessen Informationen Sie einsehen möchten");
            var ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Titel: {0}   [1]", inventar[ID].Titel);
            Console.WriteLine("Gruppe: {0}   [1]", inventar[ID].Gruppe);
            Console.WriteLine("Sachgruppe: {0}   [1]", inventar[ID].Sachgruppe);
            Console.WriteLine("Verlag: {0}   [1]", inventar[ID].Verlag);
            Console.WriteLine();
            return (ID);
        }
        public static List<Magazin> MagazinBearbeiten(List<Magazin> inventar, int ID)
        {
            string input = "0";
            string neueeingabe;
            while (input != "x")
            {
                Console.WriteLine("Wählen Sie den zu bearbitenden Eintrag (x zum beenden)");
                input = Console.ReadLine().ToLower();
                if (input == "x")
                {
                    return inventar;
                }
                Console.WriteLine("Bitte geben Sie den neuen Wert ein");
                neueeingabe = Console.ReadLine();
                switch (input)
                {
                    case "1": inventar[ID].Titel = neueeingabe; break;
                    case "2": inventar[ID].Gruppe = neueeingabe; break;
                    case "3": inventar[ID].Sachgruppe = neueeingabe; break;
                    case "4": inventar[ID].Verlag = neueeingabe; break;
                }
            }
            return inventar;
        }
    }

    
}

