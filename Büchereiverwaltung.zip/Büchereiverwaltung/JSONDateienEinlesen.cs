﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using Json.Net;
using Newtonsoft.Json.Linq;

namespace Büchereiverwaltung
{
    class JSONDateienEinlesen
    {
        public static List<Buch> JSONeinlesen()
        {
            using (StreamReader r = new StreamReader("books.json"))
            {
                string json = r.ReadToEnd();
                List<Buch> items = JsonConvert.DeserializeObject<List<Buch>>(json);
                return items;
            }
        }
        public static List<Magazin> MagazinEinlesen()
        {
            using (StreamReader r = new StreamReader("Magazine.json"))
            {
                string json = r.ReadToEnd();
                List<Magazin> items = JsonConvert.DeserializeObject<List<Magazin>>(json);
                return items;
            }
        }
        public static List<Leihliste> JSONVerleih()
        {
            using (StreamReader r = new StreamReader("Leihliste.json"))
            {
                string json = r.ReadToEnd();
                List<Leihliste> leih = JsonConvert.DeserializeObject<List<Leihliste>>(json);
                return leih;
            }
        }
        public static List<Exemplar> ExemplarEinlesen()
        {
            using (StreamReader r = new StreamReader("Exemplar.json"))
            {
                string json = r.ReadToEnd();
                List<Exemplar> items = JsonConvert.DeserializeObject<List<Exemplar>>(json);
                return items;
            }
        }
    }

    public class Buch
    {
        public string author;
        public string country;
        public string imageLink;
        public string language;
        public string link;
        public int pages;
        public string title;
        public int year;
    }

    public class Magazin
    {
        public string Titel;
        public string Gruppe;
        public string Sachgruppe;
        [JsonProperty(PropertyName = "Verlag / Herausgeber")] public string Verlag { get; set; }
    }

    public class Leihliste
    {
        public string kunde;
        public int buch;
        public DateTime verleihdatum;
        public DateTime rückgabedatum;
    }

    public class Exemplar
    {
        public int ID;
        public string Typ;
        public int Anzahl;
    }
}
