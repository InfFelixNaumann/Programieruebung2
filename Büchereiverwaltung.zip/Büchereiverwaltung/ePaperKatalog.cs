﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Büchereiverwaltung
{
    class ePaperKatalog
    {
        /*public static void AlleEPaper(List<Magazin> inventar)
        {
            Console.WriteLine("ePaper:");
            Console.WriteLine("__________");
            foreach (Magazin i in inventar)
            {
                Console.WriteLine("[{0}] {1}: '{2}'", inventar.IndexOf(i), i.Verlag, i.Titel);
                Console.WriteLine("Gruppe: {0}", i.Gruppe);
                Console.WriteLine("Sachgruppe: {0}", i.Sachgruppe);
                Console.WriteLine("Link: HierStehtDerDownloadLink");
                Console.WriteLine();
            }
        }*/
    }
}
