﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using static Büchereiverwaltung.Program;

namespace Büchereiverwaltung
{
    public class Exemplar
    {
        public static void ExemplarlisteErstellen()
        {
            var initialJson = File.ReadAllText("books.json");
            JArray feld = JArray.Parse(initialJson);
            feld.Add(feld);
            using (StreamWriter file = File.CreateText("Exemplare.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, feld);
            }

        }
    }
}
