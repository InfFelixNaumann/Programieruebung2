﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using static Büchereiverwaltung.Program;

namespace Büchereiverwaltung
{
    public class Exemplar
    {
        public static void ExemplarlisteErstellen(List<Buch> inventar)
        {
            var initialJson = File.ReadAllText("Exemplare.json");
            List<Exemplarliste> list = new List<Exemplarliste>();
            list.Add(new Exemplarliste()
            {
                BuchID = 0,
                Anzahl = 2,
            });
            using (StreamWriter file = File.CreateText("Exemplare.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, initialJson);
            }
            JArray feld = JArray.Parse(initialJson);
            foreach(Buch i in inventar)
            {
                var itemToAdd = new JObject();
                {
                    itemToAdd["BuchID"] = inventar.IndexOf(i);
                    itemToAdd["Anzahl"] = 2;
                }
                feld.Add(itemToAdd);
            }
            using (StreamWriter file = File.CreateText("Exemplare.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, feld);
            }

        }
        public class Exemplarliste
        {
            public int BuchID;
            public int Anzahl;
        }

    }
}
