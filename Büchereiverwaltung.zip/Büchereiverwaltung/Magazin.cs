﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Json.Net;
using Newtonsoft.Json.Linq;
using System.ComponentModel;
using System.Text.Json.Serialization;
using System.Dynamic;

namespace Büchereiverwaltung
{
    class Magazin
    {
        public static List<ItemMagazin> MagazinEinlesen()
        {
            using (StreamReader r = new StreamReader("Magazine.json"))
            {
                string json = r.ReadToEnd();
                List<ItemMagazin> items = JsonConvert.DeserializeObject<List<ItemMagazin>>(json);
                return items;
            }
        }

        public static void AlleMagazine(List<ItemMagazin> inventar)
        {
            Console.WriteLine("Magazine:");
            Console.WriteLine("__________");
            foreach (ItemMagazin i in inventar)
            {
                Console.WriteLine("[{0}] {1}: '{2}'", inventar.IndexOf(i),i.Verlag, i.Titel);
                Console.WriteLine("Gruppe: {0}", i.Gruppe);
                Console.WriteLine("Sachgruppe: {0}", i.Sachgruppe);
                Console.WriteLine();
            }
        }
    }
    public class ItemMagazin
    {
        public string Titel;
        public string Gruppe;
        public string Sachgruppe;
        [JsonProperty(PropertyName = "Verlag / Herausgeber")]public string Verlag { get; set; }
    }
}

