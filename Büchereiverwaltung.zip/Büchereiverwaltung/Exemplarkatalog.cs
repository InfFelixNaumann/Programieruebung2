﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using static Büchereiverwaltung.Program;

namespace Büchereiverwaltung
{
    public class Exemplarkatalog
    {
        public static List<Exemplar> ExemplarlisteErstellen(List<Buch> inventar, List<Magazin> magazin)
        {

            List<Exemplar> list = new List<Exemplar>();
            foreach (Buch i in inventar)
            {
                list.Add(new Exemplar()
                {
                    ID = inventar.IndexOf(i),
                    Typ = "Buch",
                    Anzahl = 2, 
                });
            }
            foreach (Magazin i in magazin)
            {
                list.Add(new Exemplar()
                {
                    ID = magazin.IndexOf(i),
                    Typ = "Magazin",
                    Anzahl = 2,
                });
            }

            foreach (Buch i in inventar)
            {
                list.Add(new Exemplar()
                {
                    ID = inventar.IndexOf(i),
                    Typ = "EBook",
                });
            }

            foreach (Magazin i in magazin)
            {
                list.Add(new Exemplar()
                {
                    ID = magazin.IndexOf(i),
                    Typ = "EPaper",
                });
            }
            using StreamWriter file = File.CreateText("Exemplare.json");
            JsonSerializer serializer = new JsonSerializer();
            serializer.Serialize(file, list);
            return list;
        }

        public static void GanzesInventarAnzeigen(List<Buch> buch, List<Magazin> magazin, List<Exemplar> exemplar)
        {

            foreach (Exemplar i in exemplar)
            {
                switch (i.Typ)
                {
                    case "Buch":
                        Console.WriteLine("[{0}] {1}: '{2}' , {3}. Quelle: {4}", exemplar.IndexOf(i), buch[i.ID].author, buch[i.ID].title, buch[i.ID].year, buch[i.ID].link);
                        break;
                    case "Magazin":
                        Console.WriteLine("[{0}] {1}: '{2}'", exemplar.IndexOf(i),magazin[i.ID].Verlag, magazin[i.ID].Titel);
                        Console.WriteLine("Gruppe: {0}", magazin[i.ID].Gruppe);
                        Console.WriteLine("Sachgruppe: {0}", magazin[i.ID].Sachgruppe);
                        Console.WriteLine();
                        break;
                    case "EBook":
                        Console.WriteLine("[{0}] {1}: '{2}' , {3}. Link: HierStehtDerDownloaLink", exemplar.IndexOf(i), buch[i.ID].author, buch[i.ID].title, buch[i.ID].year);
                        break;
                    case "EPaper":
                        Console.WriteLine("[{0}] {1}: '{2}'", exemplar.IndexOf(i), magazin[i.ID].Verlag, magazin[i.ID].Titel);
                        Console.WriteLine("Gruppe: {0}", magazin[i.ID].Gruppe);
                        Console.WriteLine("Sachgruppe: {0}", magazin[i.ID].Sachgruppe);
                        Console.WriteLine("Link: HierStehtDerDownloadLink");
                        Console.WriteLine("");
                        break;
                }
            }
        }
    }
}
