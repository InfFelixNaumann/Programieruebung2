﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using static Büchereiverwaltung.Program;

namespace Büchereiverwaltung
{
    public class Exemplarkatalog
    {
        public static List<Exemplar> ExemplarlisteErstellen(List<Buch> inventar)
        {

            List<Exemplar> list = new List<Exemplar>();
            foreach (Buch i in inventar)
            {
                list.Add(new Exemplar()
                {
                    BuchID = inventar.IndexOf(i),
                    Anzahl = 2, 
                });
            }

            using StreamWriter file = File.CreateText("Exemplare.json");
            JsonSerializer serializer = new JsonSerializer();
            serializer.Serialize(file, list);
            return list;
        }
    }
}
